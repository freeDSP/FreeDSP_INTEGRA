/**
 * DAC Generated Driver File
 * 
 * @file dac.c
 * 
 * @ingroup dac
 * 
 * @brief This is the generated driver implementation file for the DAC driver using PIC10/12/16/18 microcontrollers.
 *
 * @version DAC Driver Version 2.1.0
*/
/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

/**
  Section: Included Files
*/

#include <xc.h>
#include "../dac.h"

/**
  Section: DAC APIs
*/

void DAC_Initialize(void) 
{
    //DACNSS VSS; DACPSS VDD; DACEN enabled; DACOE enabled; DACLPS neg_ref; 
    DACCON0 =  0xA0;
    
    //DACR 6; 
    DACCON1 =  0x6;
}

void DAC_SetOutput (uint8_t inputData)
{
    DACCON1 =  inputData;
}

uint8_t DAC_GetOutput(void) 
{
    return DACCON1;
}
/**
 End of File
*/