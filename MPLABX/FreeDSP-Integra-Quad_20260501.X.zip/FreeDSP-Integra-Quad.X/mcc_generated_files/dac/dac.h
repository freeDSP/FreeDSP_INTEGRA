/**
 * DAC Generated Driver API Header File
 * 
 * @file dac.h
 * 
 * @defgroup  dac DAC
 * 
 * @brief This file contains the prototypes and other data types for the DAC driver using PIC10/12/16/18 microcontrollers.
 *
 * @version DAC Driver Version 2.1.0
*/
/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef DAC_H
#define DAC_H

/**
  Section: Included Files
*/

#include <stdbool.h>
#include <stdint.h>

/**
  Section: DAC APIs
*/

/**
 * @ingroup dac
 * @brief Initializes the DAC and must be called only once, before any other DAC routine is called.
 * @param None.
 * @return None.
 */
void DAC_Initialize(void);

/**
 * @ingroup dac
 * @brief Passes the digital input data into the DAC Voltage Reference Control register.
 * @param inputData - 8-bit digital data to DAC.
 * @return None.
 */
void DAC_SetOutput(uint8_t inputData);

/**
 * @ingroup dac
 * @brief Reads the digital input data sent to the DAC Voltage Reference Control register.
 * @param None.
 * @return uint8_t inputData - digital data sent to DAC.
 */
uint8_t DAC_GetOutput(void);

#endif // DAC_H
/**
 End of File
*/
