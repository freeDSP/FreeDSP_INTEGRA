 /*
 * (c) CyberPit HILO 2020
 * This software was written for the  PIC16F1938 
 * TAS6424 Amplifier board MCU version 1.00
 * 
 * Home Page: https://cyberpithilo.web.fc2.com/
 * Project Web Page https://cyberpithilo.web.fc2.com/audio/tas6424amp/index.html
 * GitHub: https://github.com/CyberPit/TAS6424-AMP-Project
 *
 * Included my original part of  software are  licensed under a Creative Commons Attribution Share-Alike 4.0 license.
 * This allows for both personal and commercial derivative works, as long as they credit "Deeignd by CyberPit HILO" 
 * and release their designs under the same license.
 * @file main.c
 * @defgroup main MAIN
 * @brief This is the generated driver implementation file for the MAIN driver.
 * @version MAIN Driver Version 1.0.2 *
 * @version Package Version: 3.1.2
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/
#pragma config LVP = ON         // Low-Voltage Programming Enable (Low-voltage programming enabled)

#include <xc.h>
#include <string.h>
#include<stdio.h>
#include <stdlib.h>
#include <stdint.h>


#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/nvm/nvm.h"
#include "disp_param.h"


// a mask value for LED DP segment        
#define DOT_ON  0x7f
#define DOT_OFF 0xff

// Time for LED Blink
#define BLINK_CYCLETIME 600
#define BLINK_ONTIME    400

// Button Push status flag value
#define NOT_PUSHED      0
#define SHORT_PUSHED    1
#define LONG_PUSHED     2  
#define YES             1
#define NO              0
#define CHATT_FILT      10  // 10mS chattering filter time
#define LONG_HOLD_THR   1500 // Long-Push Holding threshold 

// EE Address Labels
#define     EE_INITVOL  0x08
#define     EE_FACTORY  0x07
#define     EE_VOLKEEP  0x06
#define     EE_FADER    0x05
#define     EE_VOLUME   0x04
#define     EE_BALANCE  0x03
#define     EE_SOURCE   0x02
#define     EE_MODE     0x01
#define     EE_HPF      0x00
// EEPROM Preset Data
__EEPROM_DATA(0x00,0x00,0x00,0x00,0x10,0x00,0x00,0xFF);
// Values for EE
#define     FACTORY_DEFAULT  0xff
#define     NON_FACTORY 0x00
#define     MODE_2CH     1
#define     MODE_4CH     0

// I2C Device Definitions
#define     ADR_TAS6424 0x6a



// Fixed Message String
//Opening Message
//const char CyberPitStr[]="   TAS6424 AMP by CyberPit HILO 2026";
 // I2S Header I/O Mode Selection Items
const char led_amp_mode[2][7] = { "4 ch", "2 ch" };
  // MUSIC SOURCE SELECT ITEMS
const char led_src_name[4][7] = { "USB", "ADC", "SPd.F", "rASP"};
// HPF Cutoff Frequency
const char led_hpf_fc[9][7]   = {"   0","   4","   8","  15","  30","  59"," 118"," 235"," 463"};
  

// LED DP Attribute for each digit's dot
static unsigned char led_dot[5] = {DOT_OFF, DOT_OFF, DOT_OFF, DOT_OFF, DOT_OFF};
// LED DP blink attribute, if NOT zero each digit  blinks (slowest ==1)
static unsigned int blink_rate[]={0, 0, 0, 0, 0}; 
static unsigned int led_blink[]={0, 0, 0, 0, 0};
// Greeting LED message
static  char ledstr[10]="____\0\0\0\0\0";
static  char ledbuff[6]="\0\0\0\0\0";
// Current Roltaty Encoder Position Indicator
static unsigned char     RE_pos;
// Button pushed status flag, if Zero -- NotPushed, None-Zero==HoldDuration
static char button1 = NOT_PUSHED;
// Button push-hold duration counter
static  char            lcdbuff[41];
static  unsigned char   tasbuff[2];   // offset_adrr, reg_value
static signed char      gain;
static unsigned char    current_source;
static unsigned char    current_volume;
static unsigned char    current_hpf;
static unsigned char    current_fs;
static signed char      current_balance;
static signed char      current_fader;
static signed char      current_mode;  // PBTL Option


const unsigned char font7seg[]=
{
    0xff    //0x20: ' ' as space
,   0xf9    //0x21: '!'
,   0xff    //0x22: '"'
,   0xff    //0x23: '#'
,   0xff    //0x24: '$'
,   0x9c    //0x25: '%'
,   0xff    //0x26: '&'
,   0xff    //0x27: ''
,   0xff    //0x28: '('
,   0xff    //0x29: ')'
,   0xff    //0x2A: '*'
,   0xff    //0x2B: '+'
,   0xff    //0x2C: ','
,   0xbf    //0x2D: '-'
,   0x7f    //0x2E: '.'
,   0xcf    //0x2F: '/'
   
,   0xc0    //0x30: '0'
,   0xf9    //0x31: '1'
,   0xa4    //0x32: '2'
,   0xb0    //0x33: '3'
,   0x99    //0x34: '4'
,   0x92    //0x35: '5'
,   0x82    //0x36: '6'
,   0xf8    //0x37: '7'
,   0x80    //0x38: '8'
,   0x90    //0x39: '9'
,   0xf6    //0x3A: ':'
,   0xb6    //0x3B: ';'
,   0xff    //0x3C: '<'
,   0xb7    //0x3D: '='
,   0xff    //0x3E: '>'
,   0xff    //0x3F: '?'
            
,   0xa0    //0x40: '@'
,   0x88    //0x41: 'A'
,   0x83    //0x42: 'B'
,   0xc6    //0x43: 'C'
,   0xa1    //0x44: 'D'
,   0x86    //0x45: 'E'
,   0x8e    //0x46 'F'
,   0xc2    //0x47 'G'
,   0x89    //0x48 'H'
,   0xcf    //0x49: 'I'
,   0xe1    //0x4A: 'J'
,   0x87    //0x4B: 'K'
,   0xc7    //0x4C: 'L'
,   0xc8    //0x4D: 'M'
,   0xab    //0x4E: 'N'
,   0xc0    //0x4F: 'O'
            
,   0x8c    //0x50: 'P'
,   0x98    //0x51: 'Q'
,   0x88    //0x52: 'R'
,   0x92    //0x53: 'S'
,   0xce    //0x54: 'T'
,   0xc1    //0x55: 'U'
,   0xc1    //0x56: 'V'
,   0x81    //0x57: 'W'
,   0x89    //0x58: 'X'
,   0x91    //0x59: 'Y'
,   0xe4    //0x5A: 'Z'
,   0xc6    //0x5B: '['
,   0xff    //0x5C: '\'
,   0xf0    //0x5D: ']'
,   0xbc    //0x5E: '^'
,   0xf7    //0x5F: '_'
            
,   0xde    //0x60: '''
,   0xa0    //0x61: 'a'
,   0x83    //0x62: 'b'
,   0xa7    //0x63: 'c'
,   0xa1    //0x64: 'd'
,   0x86    //0x65: 'e'
,   0x8e    //0x66: 'f'
,   0x90    //0x67: 'g'
,   0x8b    //0x68: 'h'
,   0xfb    //0x69: 'i'
,   0xf1   //0x6A: 'j'
,   0x87    //0x6B: 'k'
,   0xc7    //0x6C: 'l'
,   0xc8    //0x6D: 'm'
,   0xab    //0x6E: 'n'
,   0xa3    //0x6F: 'o'
            
,   0x8c    //0x70: 'p'
,   0x98    //0x71: 'q'
,   0xaf    //0x72: 'r'
,   0x92    //0x73: 's'
,   0x87    //0x74: 't'
,   0xe3    //0x75: 'u'
,   0xe3    //0x76: 'v'
,   0x81    //0x77: 'w'
,   0x89    //0x78: 'x'
,   0x91    //0x79: 'y'
,   0xe4   //0x7A: 'z'
,   0xff    //0x7B: '{'
,   0xff    //0x7C: '|'
,   0xff    //0x7D: '}'
,   0xfe    //0x7E: '~'          
};

//
// -----Get 7seg LED display data from table array----
// 文字コードに対応した表示データを所得する（ドットは別）
//
unsigned char get7seg_font(char cdata)
{
unsigned char    fontdata;
    
    if (cdata >= 0x20)
        {
        cdata -= 0x20;
        fontdata = font7seg[cdata];
         }
    else         
        fontdata = 0xff;    
return(fontdata);
}

#define STBYn_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define STBYn_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define MUTEn_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define MUTEn_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define RE_B_GetValue()           PORTAbits.RA7
#define RE_A_GetValue()           PORTAbits.RA6
#define MODEn_GetValue()           PORTAbits.RA5

//
// EEPROM Access Code
//
#include <xc.h>
#include <stdint.h>


uint8_t myEEPROM_ReadByte(uint8_t address)
{
    while(EECON1bits.WR); // 念のため

    EEADRL = address;

    EECON1bits.EEPGD = 0;
    EECON1bits.CFGS  = 0;
    EECON1bits.RD = 1;

    return EEDATL;
}

void myEEPROM_WriteByte(uint8_t address, uint8_t data)
{
    // 前回の書き込み待ち
while(EECON1bits.WR);
// Skip if No-Chaange
if(myEEPROM_ReadByte(address) != data) 
    {
    EEADRL = address;   // アドレス
    EEDATL = data;      // データ

    EECON1bits.EEPGD = 0; // Data EEPROM
    EECON1bits.CFGS  = 0; // Configじゃない
    EECON1bits.WREN  = 1; // 書き込み許可

    uint8_t gie = INTCONbits.GIE; // 割り込み状態保存
    INTCONbits.GIE = 0;           // 割り込み禁止

    // ★ 超重要アンロックシーケンス
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;

    while(EECON1bits.WR); // 書き込み完了待ち

    INTCONbits.GIE = gie; // 割り込み復帰
    EECON1bits.WREN = 0;  // 念のため禁止
    }
 }

void myDELAY_milliseconds(uint16_t milliseconds) {
    while(milliseconds--){ 
        __delay_ms(2); 
    }
}

void set_gains(unsigned char vol, signed char bal)
{
 if (bal < 0)
    {
     tasbuff[0] = 0x05;
     tasbuff[1] =vol;
 //   I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
    tasbuff[0] = 0x06;
    tasbuff[1] = vol - abs(bal);
 //   I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
    }
 else
    {
     tasbuff[0] = 0x05;
     tasbuff[1] =vol - bal;
 //   I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
    tasbuff[0] = 0x06;
    tasbuff[1] = vol ;
//    I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
     }
 }

//
// TAS6424 Cmmand Stracture
//
typedef struct
    {
    const unsigned char addr;
    const unsigned char data;
    } Command6424;

Command6424 TAS_RESET_BTL = {0x00, 0x80};   //Reset, BTLx4, SpeakerDrive
Command6424 TAS_RESET_PBTL ={0x00, 0xF0};   //Reset, BTLx4, SpeakerDrive
Command6424 TAS_BTL    =    {0x00, 0x00};   // 4ch BTL Mode 
Command6424 TAS_PBTL   =    {0x00, 0x30};   // 2ch PBTL Mode 

Command6424 TAS_29V_DC =    {0x01, 0xB3};   // DC,130degrees,OC2,1step,29Vpeak
Command6424 TAS_29V_AC =    {0x01, 0x33};   // AC,130degrees,OC2,1step,29Vpeak
Command6424 TAS_21V_DC =    {0x01, 0xB2};   // DC,130degrees,OC2,1step,21Vpeak
Command6424 TAS_21V_AC =    {0x01, 0x32};   // AC,130degrees,OC2,1step,21Vpeak
Command6424 TAS_15V_DC =    {0x01, 0xB1};   // DC,130degrees,OC2,1step,15Vpeak
Command6424 TAS_15V_AC =    {0x01, 0x31};   // AC,130degrees,OC2,1step,15Vpeak


Command6424 TAS_OSR64 =     {0x02, 0x61};   // 44fs,OSR64,0-210-60-270
Command6424 TAS_OSR128=     {0x02, 0x65};   // 44fs, OSR128,Need Setup 28H bit5

Command6424 TAS_FS44K_I2S = {0x03, 0x04};   // 44.1k, TDM,I2S 24bit
Command6424 TAS_FS44K_TDM = {0x03, 0x24};   // 44.1k, TDM,I2S 24bit
Command6424 TAS_FS48K_I2S = {0x03, 0x44};   // 48k, TDM,I2S 24bit
Command6424 TAS_FS48K_TDM = {0x03, 0x64};   // 48k, TDM,I2S 24bit
Command6424 TAS_FS96K_I2S = {0x03, 0x84};   // 96k, TDM,I2S 24bit
Command6424 TAS_FS96K_TDM = {0x03, 0x86};   // 96k, TDM,I2S 24bit

Command6424 TAS_HiZ =       {0x04, 0x55};   // Channel State= Hi-Z
Command6424 TAS_MUTE =      {0x04, 0xAA};   // Channel State= MUTE
Command6424 TAS_UNMUTE =    {0x04, 0x00};   // Channel State= PLAY
Command6424 TAS_PLAY =      {0x04, 0x00};   // Channel State= PLAY
Command6424 TAS_DCTEST =    {0x04, 0xFF};   // Channel State= PLAY

Command6424 TAS_VOL1_INI =  {0x05, 190};   // Channel 1 Volume Default
Command6424 TAS_VOL2_INI =  {0x06, 190};   // Channel 1 Volume Default
Command6424 TAS_VOL3_INI =  {0x07, 190};   // Channel 1 Volume Default
Command6424 TAS_VOL4_INI =  {0x08, 190};   // Channel 1 Volume Default


Command6424 TAS_DCDIAG_ABORT = {0x09, 0x81}; // Abort Diagnostics
Command6424 TAS_DCDIAG_AUTO = {0x09, 0x00}; // Autorun Tests

Command6424 TAS_R_SETLIMIT12_1ohms = {0x0A, 0x11}; // Autorun Tests
Command6424 TAS_R_SETLIMIT34_1ohms = {0x0B, 0x11}; // Autorun Tests

Command6424 TAS_SHORT_CHECK12 = {0x0C, 0x00}; //(Read Only) 00 == No-Shorts
Command6424 TAS_SHORT_CHECK34 = {0x0D, 0x00}; //(Read Only) 00 == No-Shorts

Command6424 TAS_LINEOUT_CHECK = {0x0E, 0x00}; //(Read Only) 00 == No-Output Exists

Command6424 TAS_LOAD_CHECK = {0x0F, 0x00}; //(Read Only) 00==PLAY_OK 66==Open

Command6424 TAS_OC_DC_CHECK = {0x10, 0x00}; //(Read Only) 00==OK 66==Open

Command6424 TAS_GFAULT1 = {0x11, 0x00}; //(Read Only) 00==OK 
Command6424 TAS_GFAULT2 = {0x12, 0x00}; //(Read Only) 00==OK 
Command6424 TAS_WARN    = {0x13, 0x00}; //(Read Only) 00==OK 

Command6424 TAS_PIN_CLIP = {0x14, 0xFC};   // Report ClIP & OveHeat 
Command6424 TAS_PIN_ALL = {0x14, 0x00};   // Report all Warnings 

Command6424 TAS_AC_DIAG_DISABLE = {0x15, 0x00};   // 0 ==AC Diagnosis Disabled 


Command6424 TAS_CLEAR_FALT  ={0x21, 0x80};  // Clear Faults, Auto Recover
Command6424 TAS_CLEAR_FALT2 ={0x21, 0x88};  // Clear Faults, Not Report, Auto Recover
Command6424 TAS_NORMAL       ={0x21, 0x08};  // Normal Operation

Command6424 TAS_CLIP_CTRL = {0x22, 0x03}; // Non-Latch Clip Report 

Command6424 TAS_CLIP_DET = {0x23, 0x0F};  // Read ClIP Channels 

Command6424 TAS_FC4 =   {0x26, 0x40};     // HPF Fc=4Hz 
Command6424 TAS_FC7 =   {0x26, 0x41};     // HPF Fc=7.4Hz
Command6424 TAS_FC15 =  {0x26, 0x42};    // HPF Fc=15Hz
Command6424 TAS_FC30 =  {0x26, 0x43};    // HPF Fc=30Hz
Command6424 TAS_FC59 =  {0x26, 0x44};    // HPF Fc=59Hz
Command6424 TAS_FC118 = {0x26, 0x45};    // HPF Fc=118Hz
Command6424 TAS_FC235 = {0x26, 0x46};    // HPF Fc=235Hz
Command6424 TAS_FC463 = {0x26, 0x47};    // HPF Fc=453Hz

Command6424 TAS_SS_NARROW={0x28, 0x08}; // Narrow SS
Command6424 TAS_SS_WIDE = {0x28, 0x7C}; // Wide SS

Command6424 TAS_SS_ON   = {0x77, 0xFF};  // SS Enable
Command6424 TAS_SS_OFF   = {0x77, 0x00};  // SS DIsable

Command6424 TAS_SS_FAST   = {0x79, 0xFF};  // SS Fast
Command6424 TAS_SS_SLOW   = {0x79, 0x00};  // SS Slow

Command6424 TAS_BOOK0   = {0x7F, 0x00};  // Select Book 0
Command6424 TAS_PAGE0   = {0x00, 0x00};  // Select Page 0


//
// Initialize TAS6424
//
void init_tas6424(void)
{
STBYn_SetHigh();
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_BOOK0, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_PAGE0, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
current_mode = myEEPROM_ReadByte(EE_MODE);
if(current_mode == MODE_2CH)
        I2C1_Write(ADR_TAS6424,&TAS_RESET_PBTL, 2 );
else    I2C1_Write(ADR_TAS6424,&TAS_RESET_BTL, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_CLEAR_FALT, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_DCDIAG_ABORT, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_29V_DC, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_OSR64, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_FS96K_TDM, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_CLEAR_FALT, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(300);
I2C1_Write(ADR_TAS6424,&TAS_PLAY, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_VOL1_INI, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_VOL2_INI, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_VOL3_INI, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_VOL4_INI, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_NORMAL, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
STBYn_SetLow();
myDELAY_milliseconds(200);
STBYn_SetHigh();
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_CLEAR_FALT, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_NORMAL, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
I2C1_Write(ADR_TAS6424,&TAS_PLAY, 2 );
while(I2C1_IsBusy());
myDELAY_milliseconds(200);
}

//
// TAS6424 Warning Check
//
char chk6424warning(void)
{
static uint8_t read_adr, lasttime, ocdc, otshut, otwarn,clip,ilim,prail;

    tasbuff[0] = 0x05 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
 //    myEEPROM_WriteByte(0x10, tasbuff[1]);
 
    tasbuff[0] = 0x06 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
 //    myEEPROM_WriteByte(0x11, tasbuff[1]);

   tasbuff[0] = 0x07 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
 //   myEEPROM_WriteByte(0x12, tasbuff[1]);
   
    tasbuff[0] = 0x08 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
 //   myEEPROM_WriteByte(0x13, tasbuff[1]);

    tasbuff[0] = 0x10 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
 //   myEEPROM_WriteByte(0x14, tasbuff[1]);

// Clear Global Faults    
    tasbuff[0] = 0x11 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
    if (tasbuff[1])
        {
        I2C1_Write(ADR_TAS6424,&TAS_CLEAR_FALT2, 2 );
        while(I2C1_IsBusy());
        }
    tasbuff[0] = 0x12 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff,1,&tasbuff,2);
    if (tasbuff[1])
        {
        I2C1_Write(ADR_TAS6424,&TAS_CLEAR_FALT2, 2 );
        while(I2C1_IsBusy());
        }
 
    tasbuff[0] = 0x13 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff[0],1,&tasbuff[1],2);
    otwarn =tasbuff[1];

    tasbuff[0] = 0x24 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff[0],1,&tasbuff[1],2);
    clip =tasbuff[1];

    tasbuff[0] = 0x25 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff[0],1,&tasbuff[1],2);
    ilim =tasbuff[1];

    tasbuff[0] = 0x12 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff[0],1,&tasbuff[1],2);
    otshut =tasbuff[1];

    tasbuff[0] = 0x11 ;
    I2C1_WriteRead(ADR_TAS6424,&tasbuff[0],1,&tasbuff[1],2);
    prail =tasbuff[1];

    if(lasttime == (ocdc + otshut + otwarn + clip +ilim + prail ))
             return(0);
    else
     {
      lasttime = ocdc + otshut + otwarn + clip +ilim + prail ;
      return(1);
     }
 
}

//
// Select Audio Source
//
void set_source(unsigned char sourcenumber)
{ switch(sourcenumber % 5)
                        {
                        case 0:
                            IO_RA0_SetLow();
                            IO_RA1_SetLow();

                            break;
                        case 1:
                            IO_RA0_SetHigh();
                            IO_RA1_SetLow();
                            break;
                        case 2:
                            IO_RA0_SetLow();
                            IO_RA1_SetHigh();
                            break;
                        case 3:
                            IO_RA0_SetHigh();
                            IO_RA1_SetHigh();
                           break;
                        case 4:
                            break;
 
                    }
myDELAY_milliseconds(5);
//I2C1_Write(ADR_TAS6424, &TAS_CLEAR_FALT, 2 );
//I2C1_Write(ADR_TAS6424, &TAS_NORMAL, 2 );
}


//-----------NonClick Rotary Encoder Rread --------------
// 直前の状況と今回の状況を合わせた16通りの組合せから
// 左右どちらに回転をしたのか判定することができる
// 加速なしの高分解能で戻り値は (-1,0,1) の３通り
//--------------------------------------------------------

signed char readRE(void){
 //const char RE_states[] ={0, 1,-1, 2,-1, 0, 2, 1,-1, 2,-1,1, 2,-1, 1, 0};
 //const char RE_states[] ={0,-1, 1, 0, 1, 0, 0,-1,-1, 0, 0, 1, 0, 1,-1, 0};
// const char RE_states[] ={0,-1, 0, 3, 1, 0, 3, 0, 0, 3, 0, 0, 3, 0, 0, 0};
const signed char RE_states[] =    {0,-1, 0, 5, 1, 0, 5, 0, 0, 5, 5, 0, 5, 0, 0, 0};
 static signed char direction;
  static unsigned char RE_old = 0;               // 共通変数（値は保存）
  unsigned char RE_now;
  signed char  offset;
  RE_now =  RE_B_GetValue() * 2 +  RE_A_GetValue();           // 今回情報の読取
  RE_old <<= 2;                         // 前回の読取値と
  RE_old |= ( RE_now & 0x03 );          // 今回の読取値を組合わせる
  if ((offset = RE_states[( (RE_old & 0x0F))]) == 5)
    return (1 * direction * offset);  // 変化分を戻り値をする
  direction = offset;
  return(offset);
}

//-----------Clicking Rotary Encoder Rread --------------
// A相のクリック安定点ではB相を読まない
// A相がONになるタイミングで左右どちらに
// 回転をしたのか判定。　戻り値は (-1,0,1) の３通り
//--------------------------------------------------------
signed char read_clickRE(void){
  static unsigned char interval;
  static signed char index;
     signed char current;
   
     current = RE_B_GetValue();
   if((current != index) && (current== 0))
        {  // RE_Aが1から0に変化しているとき
        index =current; // Save this time level of RE_A=0
        current = RE_A_GetValue() ? 1 : -1;     // RE_Bの値で時計回り、反時計回りが判定で角速度対応する
        if (interval <7)
           current *=2; // Accelrarate Value Change
        if (interval <15)
           current *=2; // Accelrarate Value Change
        if (interval <30)
           current *=2; // Accelrarate Value Change
        interval =0;
        }
   else
        {                            // RE_Aが0から1に変化しているとき、RE_Bのみ変化する場合は無視
        index = current;
        current = 0;
        if (interval <127)
            ++interval;
        }
 return(current);   // Return changed offset value
}



/*
 Display String on the LED
 */
void puts_led(char *str)
{
#define DOT 0
#define CHR 1
unsigned char *cpoint;
unsigned char column;
char    last;

column = 0;   
cpoint =(unsigned char *)(str);  // Point Strings top
    if (*cpoint == '.')
            {
            ledbuff[column]= 0x20;
            led_dot[column++]= DOT_ON;
             last=DOT;
            }
    else
            {
            ledbuff[column] = *(cpoint);
            led_dot[column]= DOT_OFF;
            last=CHR;
            }
    ++cpoint;
        do
        {
if (*cpoint == '.')
           {
           if(last==DOT)
                {
                ledbuff[column]= 0x20;
                }
            led_dot[column++]= DOT_ON;
            last=DOT;    
            }
        else 
            {
            if(last==CHR)
                ++column;
            ledbuff[column] = *(cpoint);
            led_dot[column]= DOT_OFF;
            last=CHR;
            }
        ++cpoint;
        }
        while(*cpoint != NULL);

while(column <=5)
    {
    ledbuff[++column] = 0x20;
    }
}


//
// Set Gain String on LED Buffer
//
void    set_gainstr(unsigned char gval)
{
if (gval <9)
         strcpy( ledstr, "OFF");
else   
         {
         gain = (signed char) (((signed int)gval - (signed int)0x00cf)/2);
         sprintf(ledstr, "%3d", (signed char)gain);
         if (gval == 0xce)
              ledstr[1] = 0x2d;  // Special display case Add '-' only for -0.5dB
         if(gval & 0x01)
              strcat(ledstr, ".0 ");
         else  strcat(ledstr, ".5 ");
         }
 puts_led(ledstr);
}

//
// Set TAS6424 Each Channel Gain
// Set TAS6424 Volume Resistors
//
void set_tas_gain(unsigned char vol, signed char bal, signed char fade)
{
 unsigned char   vol1, vol2, vol3, vol4;
 
 vol1 =vol2 =vol3 =vol4 =vol;
 
// Calculate Volume offset Value
if (bal < 0)
    {
    vol2 -= abs(bal);
    vol4 -= abs(bal);
    }
    else
    {
    vol1 -=bal;
    vol3 -=bal;
    }
if (fade < 0)
    {
    vol1 -= abs(fade);
    vol2 -= abs(fade);
    }
    else
    {
    vol3 -=fade;
    vol4 -=fade;
    }
// Set Each Channl Volume1-4 Value
    while(I2C1_IsBusy());
    tasbuff[0] = 0x06;
    tasbuff[1] =vol2;
    I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
    while(I2C1_IsBusy());
    tasbuff[0] = 0x07;
    tasbuff[1] =vol3;
    I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
    while(I2C1_IsBusy());
    tasbuff[0] = 0x08;
    tasbuff[1] = vol4;
    I2C1_Write(ADR_TAS6424, &tasbuff, 2 ); 
    while(I2C1_IsBusy());
    tasbuff[0] = 0x05;
    tasbuff[1] =vol1;
    I2C1_Write(ADR_TAS6424, &tasbuff, 2 );
    while(I2C1_IsBusy());
 }

void led_blink_off(void)
{
led_blink[3]= led_blink[2]= led_blink[1]= led_blink[0]= blink_rate[3]=blink_rate[2]= blink_rate[1]=blink_rate[0]=0; // Non blink LED    
}

void led_blink_on(void)
{
  blink_rate[3]=blink_rate[2]= blink_rate[1]=blink_rate[0]=1; // blink LED    
}


/*
    INTURRUPT SERVICE ROUTINE
 */
static unsigned int fl, fh;

//
// Timer-1 Intrruupt Suroutine
//
static void myTMR1_ISR(void)
 {
 // add your TMR1 interrupt custom code
 // or set custom function using TMR1_SetInterruptHandler()
 static unsigned char  intcnt;    
 static unsigned int pushcnt = 0;
 static unsigned char pushstat = 0;
 static signed char    RE_offset;

 switch ( intcnt++)
        {
        case 0:
            {
             IO_RC6_SetLow();
             if(led_blink[0] < BLINK_ONTIME)
                    IO_RC0_SetHigh();
             else IO_RC0_SetLow();
            PORTB =  led_dot[0] & get7seg_font(ledbuff[0]);
            break;
            }
        case 1:
           {
           IO_RC0_SetLow();
           if(led_blink[1] < BLINK_ONTIME)
                      IO_RC1_SetHigh();
            else    IO_RC1_SetLow();
            PORTB = led_dot[1] & get7seg_font(ledbuff[1]);
            break;
            }
        case 2:
           {
           IO_RC1_SetLow();
           if(led_blink[2] < BLINK_ONTIME)
                      IO_RC2_SetHigh();
           else     IO_RC2_SetLow();
            PORTB = led_dot[2] & get7seg_font(ledbuff[2]);
            break;
            }
        case 3:
            {
           IO_RC2_SetLow();
           if(led_blink[3] < BLINK_ONTIME)
                      IO_RC5_SetHigh();
           else     IO_RC5_SetLow();
            PORTB = led_dot[3] & get7seg_font(ledbuff[3]);
            break;
            }
        case 4:
            {
           IO_RC5_SetLow();
           if(led_blink[4] < BLINK_ONTIME)
                      IO_RC6_SetHigh();
           else     IO_RC6_SetLow();
            PORTB = led_dot[4] & get7seg_font(ledbuff[4]);
            break;
            }
        default:
          intcnt = 0; 
        }
RE_offset =read_clickRE();
if (RE_offset > 0)  
         {
         // if offset is positive
         if (RE_pos > 247)
                {
                if (238> (unsigned char)(RE_pos + RE_offset))
                    RE_pos =255;
                }
         else     RE_pos   += RE_offset;
         // Update Rotary Ecncoder position
        }
 else   {
         // if offset is negative        
         if (RE_pos < 8)
                {
                if (17 < (unsigned char)(RE_pos + RE_offset))
                    RE_pos =0;
                }
         else
                 RE_pos   += RE_offset;
         // Update Rotary Ecncoder position
        }
 // if blink rate defined then proceed that digit blink counter
 if(led_blink[0]<=BLINK_CYCLETIME) 
         led_blink[0] += blink_rate[0]; 
else   led_blink[0] = 0;
if(led_blink[1]<=BLINK_CYCLETIME)
        led_blink[1] += blink_rate[1];
else   led_blink[1] = 0;
if(led_blink[2]<=BLINK_CYCLETIME)
        led_blink[2] += blink_rate[2];
 else   led_blink[2] = 0;
if(led_blink[3]<=BLINK_CYCLETIME)
        led_blink[3] += blink_rate[2];
 else   led_blink[3] = 0;
if(led_blink[4]<=BLINK_CYCLETIME)
        led_blink[4] += blink_rate[2];
 else   led_blink[4] = 0;
// if Button is down countup holding duration
if (MODEn_GetValue() == HIGH)
    {
    if (pushstat !=0)
        {
        button1 = pushstat; // Update Button Status
        pushstat = NOT_PUSHED;  // Clear for next push
        }
    else
        {
         pushcnt =0; // Skip because of chattaing
        }
    }
else // if PUSHED
    {
    ++pushcnt;
    if (pushcnt > CHATT_FILT)
        {
        pushstat = 1;// Short pushing
        if (pushcnt > LONG_HOLD_THR)
             pushstat = 2;
        }
    }
}


//
/*
//    The Main application
*/
//
unsigned int main(void)
{
    unsigned int    count, nochange_count;
    unsigned char   volkeep_flag, last_RE_pos,volchange_flag;
    unsigned char   warn1, warn2, warn3;
    
     // System Initialize : 
    SYSTEM_Initialize();
    myDELAY_milliseconds(200); // Wait for H/W transients
    NVM_Initialize();
    myDELAY_milliseconds(100); // Wait for H/W transients
    STBYn_SetLow(); // Disable Standby
    
   myDELAY_milliseconds(10); // Wait for a hardware stable
   
    // Enable the Timer-1 Interrupts 
    TMR1_OverflowCallbackRegister(myTMR1_ISR);
    TMR1_Start();
     myDELAY_milliseconds(100); // Wait for H/W transients
    
     //  I2C1_Initialize();
    I2C1_Initialize();


    // Set Factory Preset Values
     if(myEEPROM_ReadByte(EE_FACTORY) != NON_FACTORY)
        {
        // Load Factory defaults
         myEEPROM_WriteByte(EE_VOLUME, current_volume=151);
         myEEPROM_WriteByte(EE_INITVOL, current_volume=151);
         myEEPROM_WriteByte(EE_BALANCE, current_balance);
         myEEPROM_WriteByte(EE_FADER, current_fader);
         myEEPROM_WriteByte(EE_SOURCE, current_source=2);
         myEEPROM_WriteByte(EE_HPF, current_hpf = 0);
         myEEPROM_WriteByte(EE_MODE, current_mode= MODE_4CH);
         myEEPROM_WriteByte(EE_FACTORY, NON_FACTORY);
        }
    // or Restore setting from EEPROM
    current_volume      = myEEPROM_ReadByte(EE_VOLUME);
    current_balance     = myEEPROM_ReadByte(EE_BALANCE);
    current_fader       = myEEPROM_ReadByte(EE_FADER);
    current_source      = myEEPROM_ReadByte(EE_SOURCE);
    current_hpf         = myEEPROM_ReadByte(EE_HPF);
    current_mode        = myEEPROM_ReadByte(EE_MODE);
    volkeep_flag        = myEEPROM_ReadByte(EE_VOLKEEP);

    // Local Flag
    volchange_flag      = NO;
 
    // Restore Setting for Volume Loop Mode and Source
    if(NO == volkeep_flag)
        current_volume = myEEPROM_ReadByte(EE_INITVOL);
    RE_pos = current_volume;
    set_gainstr(current_volume);  
    set_source(current_source);


    // Enable the Global Interrupts 
    INTERRUPT_GlobalInterruptEnable(); 
    
    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 
    myDELAY_milliseconds(100); 
    // Wait for a hardware stable
    puts_led("v1.01");  
     myDELAY_milliseconds(100);        
  
    // Initalize TA6424
    //init_tas6424_hayashi();
    init_tas6424();
   myDELAY_milliseconds(100); 
    led_blink_off();
    puts_led("H1LO");  
    myDELAY_milliseconds(300); 
    set_gainstr(current_volume);
    myDELAY_milliseconds(100); 
    set_tas_gain(current_volume, current_balance, current_fader);

                          
// LCD Setup
//    i2c_lcd_init();                                                                   
//   i2c_lcd_ulcursor_off();     
//    i2c_lcd_home(); //         i2c_lcd_set_cursor_pos(0, 0);
//    sprintf(lcdbuff,"Firmware: 2020JUN06"); 
//    i2c_lcd_puts(lcdbuff);  
//    DELAY_milliseconds(800); 
//    i2c_lcd_clear();
   
     while (1)
        {
        /*
         * Source Select
         */ 
         
        if (button1 == SHORT_PUSHED)
            {
            RE_pos = current_source;  
            puts_led("SEL ");
            button1 = NOT_PUSHED;   // Clear for nettime
            myDELAY_milliseconds(800);
            puts_led("　　　");
            myDELAY_milliseconds(200);
            button1 = NOT_PUSHED;   // Clear for nexttime
            led_blink_on();// blink LED
            while (button1 == NOT_PUSHED)
                {
                current_source = RE_pos;
                puts_led(led_src_name[current_source % 4]);
                //lcd_disp_param();
                }
            current_source%=4;
            button1 = NOT_PUSHED;   // Clear for nettime
            MUTEn_SetLow(); // Muting start
            I2C1_Write(ADR_TAS6424,&TAS_MUTE, 2 );
            myEEPROM_WriteByte(EE_SOURCE, (current_source));
            set_source(current_source); // Switch Source
            RE_pos = current_volume;    // Restore Volume Setting
            set_gainstr(current_volume);
            led_blink_off();// Non blink LED
            puts_led(ledstr);
            MUTEn_SetHigh(); // Muting release
            I2C1_Write(ADR_TAS6424,&TAS_PLAY, 2 );
            }
        
        /*
         * Parameter Configuration
         */
        if (button1 == LONG_PUSHED)
            {
            //
            // Balance Settup
            //
            myEEPROM_WriteByte(EE_FACTORY, NON_FACTORY); // Erace Factory Mode flag
            RE_pos = 64 + current_balance ;  
            puts_led("BAL");
            myDELAY_milliseconds(1500);
            puts_led("　　　 ");
            myDELAY_milliseconds(200);
            led_blink_on();
            button1 = NOT_PUSHED;   // Clear for nettime
            while (button1 == NOT_PUSHED)
                {
                sprintf(ledbuff, "%4d",(current_balance=(signed char)(RE_pos-64)));
                puts_led(ledbuff);
                //lcd_disp_param();
                set_tas_gain(current_volume, current_balance, current_fader);
                }
            button1 = NOT_PUSHED;   // Clear for nettime
            myEEPROM_WriteByte(EE_BALANCE, current_balance);
            led_blink_off();
            sprintf(ledbuff, "%4d",current_balance);
            set_gains(current_volume, current_balance);
            puts_led(ledbuff);
            myDELAY_milliseconds(500);
            puts_led("     ");
            myDELAY_milliseconds(1500);
            
            //
            // Fader Settup
            //
            RE_pos = 64 + current_fader;  
            puts_led("FAdE");
            myDELAY_milliseconds(1500);
            puts_led("　　　");
            myDELAY_milliseconds(200);
            led_blink_on();
            button1 = NOT_PUSHED;   // Clear for nettime
            while (button1 == NOT_PUSHED)
                {
                sprintf(ledbuff, "%4d",(current_fader=(signed char)(RE_pos-64)));
                puts_led(ledbuff);
                //lcd_disp_param();
                set_tas_gain(current_volume, current_balance, current_fader);
                }
            button1 = NOT_PUSHED;   // Clear for nettime
            myEEPROM_WriteByte(EE_FADER, current_fader);
            led_blink_off();
            sprintf(ledbuff, "%4d",current_fader);
            set_gains(current_volume, current_fader);
            puts_led(ledbuff);
            myDELAY_milliseconds(500);
            puts_led("     ");
            myDELAY_milliseconds(1500);
            
            //
            // HPF Setup
            //
            RE_pos = current_hpf;  
            puts_led("HPF");
            myDELAY_milliseconds(1500);
            puts_led("     ");
            myDELAY_milliseconds(200);
            led_blink_on();
            button1 = NOT_PUSHED;   // Clear for nexttime
            while (button1 == NOT_PUSHED)
                {
                current_hpf = RE_pos%9;
                strcpy(ledbuff,  led_hpf_fc[current_hpf]);
                puts_led(ledbuff);
                //lcd_disp_param();
                if(current_hpf == 0)
                    {
                    I2C1_Write(ADR_TAS6424,&TAS_29V_DC, 2 );
                    while(I2C1_IsBusy());
                    myDELAY_milliseconds(100);
                    }
                else
                    {
                    I2C1_Write(ADR_TAS6424,&TAS_29V_AC, 2 );
                    while(I2C1_IsBusy());
                    myDELAY_milliseconds(100);
                    tasbuff[0] = 0x26;
                    tasbuff[1] = 0x3f + current_hpf;
                    I2C1_Write(ADR_TAS6424,&tasbuff,2);
                    }
                }
            button1 = NOT_PUSHED;   // Clear for nettime
            myEEPROM_WriteByte(EE_HPF, current_hpf);
            led_blink_off();
//          if( current_direction == I2S_OUTMODE)
//              I2C1_Write(ADR_PCM9211,&I2S_OUT, 2 );  
//          else
//              I2C1_Write(ADR_PCM9211,&I2S_IN, 2 ); 
            strcpy(ledbuff,  led_hpf_fc[current_hpf]);
            puts_led(ledbuff);
            myDELAY_milliseconds(500);
            puts_led("     ");
            myDELAY_milliseconds(1500);

            //
            // PBTL Mode Setting
            //
            RE_pos = current_mode;
            puts_led("A-CH");
            myDELAY_milliseconds(900);
            puts_led("     ");
            myDELAY_milliseconds(100);
            led_blink_on();
            //lcd_disp_param();
            button1 = NOT_PUSHED;   // Clear for nexttime
            while (button1 == NOT_PUSHED)
                {
                current_mode = RE_pos%2;
                strcpy(ledbuff,  led_amp_mode[current_mode]);
                puts_led(ledbuff);
                //lcd_disp_param();
                }
            myEEPROM_WriteByte(EE_MODE, current_mode);
            led_blink_off();
            button1 = NOT_PUSHED;   // Clear for nettime
            myDELAY_milliseconds(500);
            puts_led("     ");
            myDELAY_milliseconds(500);
 
            //
            // Volume Keep & Restore Setting
            //
            RE_pos = current_volume;
            puts_led("VOL");
            myDELAY_milliseconds(900);
            puts_led("     ");
            set_gainstr(current_volume);
            myDELAY_milliseconds(100);
            led_blink_on();
            //lcd_disp_param();
            button1 = NOT_PUSHED;   // Clear for nexttime
            while (button1 == NOT_PUSHED)
                {
                current_volume =  RE_pos;    // update psition
                //lcd_disp_param();
                if(RE_pos <9)
                    {
                    strcpy(ledstr,"LAST");
                    myEEPROM_WriteByte(EE_VOLKEEP, YES);
                    volkeep_flag = YES;
                    }
                else
                    { 
                    set_gainstr(current_volume);
                    myEEPROM_WriteByte(EE_VOLKEEP, NO);
                    volkeep_flag = NO;
                    }
                puts_led(ledstr);
                }
            myEEPROM_WriteByte(EE_INITVOL, current_volume);
            led_blink_off();
            button1 = NOT_PUSHED;   // Clear for nextime
            myDELAY_milliseconds(500);
            puts_led("　 　　");
            puts_led("SAVE");
            myDELAY_milliseconds(2000);
            puts_led("     ");
            myDELAY_milliseconds(1000);
            set_gainstr(current_volume=RE_pos);
            set_tas_gain(current_volume, current_balance, current_fader);
            puts_led(ledstr);
            }
    //
    // CHeak and Clear Warnings
    //    
    if (chk6424warning())
            {
            I2C1_WriteRead(ADR_TAS6424,&TAS_GFAULT1, 1,&warn1,1);
            I2C1_WriteRead(ADR_TAS6424,&TAS_GFAULT2, 1,&warn2,1);
            I2C1_WriteRead(ADR_TAS6424,&TAS_WARN, 1,&warn3,1);
           if(warn1 | warn2 | warn3)
                {
                //Clear_param();
                I2C1_Write(ADR_TAS6424, &TAS_CLEAR_FALT, 2 );   // Run TAS6424
                I2C1_Write(ADR_TAS6424, &TAS_NORMAL, 2 );   // Run TAS6424
                }
            }
    //
    // Update Volume Position
    //
    if((last_RE_pos != RE_pos))
        {
        volchange_flag = YES;
        current_volume=RE_pos;
        last_RE_pos = RE_pos;
        nochange_count =0;
        set_tas_gain(current_volume, current_balance, current_fader);
        set_gainstr(RE_pos);
        }
    else
        {
        if (nochange_count <= 0x03e8) 
            ++nochange_count; // Count No-Rotation interval
        else                  
            {   // About 1Sec After rotation stopped 
            if((YES == volkeep_flag) && (volchange_flag == YES))
                myEEPROM_WriteByte(EE_VOLUME, current_volume); // Save volume position
            volchange_flag = NO;
            nochange_count =0; 
            }
         }

    }
// Disable the Global Interrupts 
//INTERRUPT_GlobalInterruptDisable(); 
// Disable the Peripheral Interrupts 
//INTERRUPT_PeripheralInterruptDisable(); 
}